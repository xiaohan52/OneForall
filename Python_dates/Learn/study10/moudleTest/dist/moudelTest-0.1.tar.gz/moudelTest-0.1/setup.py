from distutils.core import setup
setup(name='moudelTest',version='0.1',description='my first module',
      author='陈文星',py_modules=['moudelTest'])